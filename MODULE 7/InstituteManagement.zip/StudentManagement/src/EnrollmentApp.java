
import com.dao.EnrollmentDao;
import com.pojo.CoursePojo;
import com.pojo.EnrollmentPojo;
import java.util.List;
import java.util.Scanner;

public class EnrollmentApp {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Enrollment Management MENU ---");
            System.out.println("1. Enroll Student in a Course");
            System.out.println("2. View All Enrollments");
            System.out.println("3. View Courses for a Specific Student");
            System.out.println("4. Cancel an Enrollment");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    EnrollmentPojo enrollmentToAdd = new EnrollmentPojo();
                    System.out.print("Enter Student ID to enroll: ");
                    enrollmentToAdd.setStudentId(scanner.nextInt());
                    System.out.print("Enter Course ID to enroll in: ");
                    enrollmentToAdd.setCourseId(scanner.nextInt());
                    scanner.nextLine();
                    EnrollmentDao.enrollStudent(enrollmentToAdd);
                    break;
                case 2:
                    System.out.println("\n--- List of All Enrollments ---");
                    List<EnrollmentPojo> enrollments = EnrollmentDao.viewAllEnrollments();
                    if (enrollments.isEmpty()) {
                        System.out.println("No enrollments found.");
                    } else {
                        for (EnrollmentPojo e : enrollments) {
                            System.out.println("Enrollment ID: " + e.getEnrollmentId() + ", Student: " + e.getStudentName() + ", Course: " + e.getCourseName() + ", Date: " + e.getEnrollmentDate());
                        }
                    }
                    break;
                case 3:
                    System.out.print("Enter Student ID to view their courses: ");
                    int studentId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("\n--- Courses for Student ID: " + studentId + " ---");
                    List<CoursePojo> studentCourses = EnrollmentDao.viewCoursesByStudent(studentId);
                    if (studentCourses.isEmpty()) {
                        System.out.println("This student is not enrolled in any courses.");
                    } else {
                        for (CoursePojo c : studentCourses) {
                            System.out.println("Course ID: " + c.getId() + ", Name: " + c.getName());
                        }
                    }
                    break;
                case 4:
                    System.out.print("Enter the Enrollment ID to cancel: ");
                    int enrollmentId = scanner.nextInt();
                    scanner.nextLine();
                    EnrollmentDao.cancelEnrollment(enrollmentId);
                    break;
                case 5:
                    System.out.println("Exiting Enrollment Management. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
