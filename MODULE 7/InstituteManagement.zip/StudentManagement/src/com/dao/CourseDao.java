package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.pojo.CoursePojo;

public class CourseDao {

    public static Connection myconnection() {
        Connection cn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost/institute_db", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return cn;
    }

    public static int insert(CoursePojo p) {
        int a = 0;
        Connection cn = myconnection();
        String s = "insert into courses(course_name, course_fee, course_duration) values(?,?,?)";
        try {
            PreparedStatement ps = cn.prepareStatement(s);
            ps.setString(1, p.getName());
            ps.setInt(2, p.getFee());
            ps.setString(3, p.getDuration());
            a = ps.executeUpdate();
            if (a > 0) System.out.println("Course inserted");
        } catch (SQLException e) {
            System.out.println("Course not inserted");
            e.printStackTrace();
        }
        return a;
    }

    public static int update(CoursePojo p) {
        int a = 0;
        Connection cn = myconnection();
        String s = "update courses set course_fee=?, course_duration=? where course_id=?";
        try {
            PreparedStatement ps = cn.prepareStatement(s);
            ps.setInt(1, p.getFee());
            ps.setString(2, p.getDuration());
            ps.setInt(3, p.getId());
            a = ps.executeUpdate();
            if (a > 0) System.out.println("Course updated");
        } catch (SQLException e) {
            System.out.println("Course not updated");
            e.printStackTrace();
        }
        return a;
    }

    public static int delete(CoursePojo p) {
        int a = 0;
        Connection cn = myconnection();
        String s = "delete from courses where course_id=?";
        try {
            PreparedStatement ps = cn.prepareStatement(s);
            ps.setInt(1, p.getId());
            a = ps.executeUpdate();
            if (a > 0) System.out.println("Course deleted");
        } catch (SQLException e) {
            System.out.println("Course not deleted");
            e.printStackTrace();
        }
        return a;
    }

    public static List<CoursePojo> fetch() {
        List<CoursePojo> al = new ArrayList<>();
        Connection cn = myconnection();
        String s = "select * from courses";
        try {
            PreparedStatement ps = cn.prepareStatement(s);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                CoursePojo p = new CoursePojo();
                p.setId(rs.getInt("course_id"));
                p.setName(rs.getString("course_name"));
                p.setFee(rs.getInt("course_fee"));
                p.setDuration(rs.getString("course_duration"));
                al.add(p);
            }
        } catch (SQLException e) {
            System.out.println("Courses not fetched");
            e.printStackTrace();
        }
        return al;
    }
}
