package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.pojo.CoursePojo;
import com.pojo.EnrollmentPojo;

public class EnrollmentDao {

    public static Connection myconnection() {
        Connection cn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            cn = DriverManager.getConnection("jdbc:mysql://localhost/institute_db", "root", "");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return cn;
    }

    public static int enrollStudent(EnrollmentPojo p) {
        int a = 0;
        Connection cn = myconnection();
        String s = "insert into enrollments(student_id, course_id, enrollment_date) values(?,?,?)";
        try {
            PreparedStatement ps = cn.prepareStatement(s);
            ps.setInt(1, p.getStudentId());
            ps.setInt(2, p.getCourseId());
            ps.setDate(3, new java.sql.Date(System.currentTimeMillis())); 
            a = ps.executeUpdate();
            if (a > 0) System.out.println("Student enrolled successfully");
        } catch (SQLException e) {
            System.out.println("Enrollment failed");
            e.printStackTrace();
        }
        return a;
    }
    
    public static int cancelEnrollment(int enrollmentId) {
        int a = 0;
        Connection cn = myconnection();
        String s = "delete from enrollments where enrollment_id = ?";
        try {
            PreparedStatement ps = cn.prepareStatement(s);
            ps.setInt(1, enrollmentId);
            a = ps.executeUpdate();
            if (a > 0) System.out.println("Enrollment cancelled");
        } catch (SQLException e) {
            System.out.println("Cancellation failed");
            e.printStackTrace();
        }
        return a;
    }

    public static List<EnrollmentPojo> viewAllEnrollments() {
        List<EnrollmentPojo> al = new ArrayList<>();
        Connection cn = myconnection();
        String s = "SELECT e.enrollment_id, s.name AS student_name, c.course_name, e.enrollment_date " +
                   "FROM enrollments e " +
                   "JOIN students s ON e.student_id = s.student_id " +
                   "JOIN courses c ON e.course_id = c.course_id";
        try {
            PreparedStatement ps = cn.prepareStatement(s);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                EnrollmentPojo p = new EnrollmentPojo();
                p.setEnrollmentId(rs.getInt("enrollment_id"));
                p.setStudentName(rs.getString("student_name"));
                p.setCourseName(rs.getString("course_name"));
                p.setEnrollmentDate(rs.getDate("enrollment_date"));
                al.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return al;
    }

    public static List<CoursePojo> viewCoursesByStudent(int studentId) {
        List<CoursePojo> al = new ArrayList<>();
        Connection cn = myconnection();
        String s = "SELECT c.course_id, c.course_name, c.course_fee, c.course_duration " +
                   "FROM enrollments e " +
                   "JOIN courses c ON e.course_id = c.course_id " +
                   "WHERE e.student_id = ?";
        try {
            PreparedStatement ps = cn.prepareStatement(s);
            ps.setInt(1, studentId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                CoursePojo p = new CoursePojo();
                p.setId(rs.getInt("course_id"));
                p.setName(rs.getString("course_name"));
                p.setFee(rs.getInt("course_fee"));
                p.setDuration(rs.getString("course_duration"));
                al.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return al;
    }
}
