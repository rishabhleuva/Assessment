package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pojo.StudentPojo;

public class StudentDao {
	
	public static Connection myconnection(){
		Connection cn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("connection not found");
			e.printStackTrace();
		}
		
		try {
			cn = DriverManager.getConnection("jdbc:mysql://localhost/institute_db","root","");
		} catch (SQLException e) {
			
			System.out.println("db not found");
			e.printStackTrace();
		}
		return cn;
	}
	
	public static int insert(StudentPojo p) {
		int a = 0;
		
		Connection cn = myconnection();
		
		String s = "insert into students(name,email,phone,address) values(?,?,?,?)";
		
		try {
			PreparedStatement ps = cn.prepareStatement(s);
			ps.setString(1, p.getName());
			ps.setString(2, p.getEmail());
			ps.setString(3, p.getPhone());
			ps.setString(4, p.getAddress());
			
			a = ps.executeUpdate();
			
			if(a>0) {
				System.out.println("data inserted");
			}
			
		} catch (SQLException e) {

			System.out.println("data not inserted");
			e.printStackTrace();
		}
		
		return a;
	}
	
	
	public static int update(StudentPojo p) {
		int a = 0;
		
		Connection cn = myconnection();
		
		String s = "update students set name=?,email=?,phone=?,address=? where student_id=?";
		
		try {
			PreparedStatement ps = cn.prepareStatement(s);
			ps.setString(1, p.getName());
			ps.setString(2, p.getEmail());
			ps.setString(3, p.getPhone());
			ps.setString(4, p.getAddress());
			ps.setInt(5, p.getId());

			a = ps.executeUpdate();
			
			if(a>0) {
				System.out.println("data updated");
			}
			
		} catch (SQLException e) {

			System.out.println("data not updated");
			e.printStackTrace();
		}
		
		return a;
	}
	
	public static int delete(StudentPojo p) {
		int a = 0;
		
		Connection cn = myconnection();
		
		String s = "delete from students where student_id=?";
		
		try {
			PreparedStatement ps = cn.prepareStatement(s);
			ps.setInt(1, p.getId());
			a = ps.executeUpdate();
			
			if(a>0) {
				System.out.println("data deleted");
			}
			
		} catch (SQLException e) {

			System.out.println("data not deleted");
			e.printStackTrace();
		}
		
		return a;
	}
	
	public static List<StudentPojo> fetch(){
		
		List<StudentPojo> al = new ArrayList<>();
		
		Connection cn = myconnection();
		
		String s = "select * from students";
		
		try {
			PreparedStatement ps = cn.prepareStatement(s);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				StudentPojo p = new StudentPojo();
				p.setId(rs.getInt(1));
				p.setName(rs.getString(2));
				p.setEmail(rs.getString(3));
				p.setPhone(rs.getString(4));
				p.setAddress(rs.getString(5));
				
				al.add(p);
				
			}
			
			
		} catch (SQLException e) {

			System.out.println("data not fetched");
			e.printStackTrace();
		}
		
		return al;
		
	}
	
	public static StudentPojo fetchbyid(int id) {
		
		StudentPojo a = null;
		
		Connection cn = myconnection();
		
		String s = "select * from students where student_id=?";
		
		
		try {
			PreparedStatement ps = cn.prepareStatement(s);
			
			ps.setInt(1, id);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				a= new StudentPojo();
				a.setId(rs.getInt(1));
				a.setName(rs.getString(2));
				a.setEmail(rs.getString(3));
				a.setPhone(rs.getString(4));
				a.setAddress(rs.getString(5));
				
			}
			
			
		} catch (SQLException e) {
			System.out.println("data not fetched");
			e.printStackTrace();
		}
		
		
		return a;
		
		
	}
public static StudentPojo fetchbyname(String id) {
		
		StudentPojo a = null;
		
		Connection cn = myconnection();
		
		String s = "select * from students where name=?";
		
		
		try {
			PreparedStatement ps = cn.prepareStatement(s);
			
			ps.setString(1, id);
			
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()) {
				
				a= new StudentPojo();
				a.setId(rs.getInt(1));
				a.setName(rs.getString(2));
				a.setEmail(rs.getString(3));
				a.setPhone(rs.getString(4));
				a.setAddress(rs.getString(5));
				
			}
			
			
		} catch (SQLException e) {
			System.out.println("data not fetched");
			e.printStackTrace();
		}
		
		
		return a;
		
		
	}
	
	
}
