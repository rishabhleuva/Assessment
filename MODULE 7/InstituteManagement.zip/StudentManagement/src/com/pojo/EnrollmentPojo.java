package com.pojo;

import java.sql.Date;

public class EnrollmentPojo {

    private int enrollmentId;
    private int studentId;
    private int courseId;
    private Date enrollmentDate;

    private String studentName;
    private String courseName;
    
    public int getEnrollmentId() { 
    	return enrollmentId; 
    	}
    
    public void setEnrollmentId(int enrollmentId) { 
    	this.enrollmentId = enrollmentId; 
    	}
    
    public int getStudentId() { 
    	return studentId; 
    	}
    
    public void setStudentId(int studentId) { 
    	this.studentId = studentId; 
    	}
    
    public int getCourseId() { 
    	return courseId; 
    	}
    
    public void setCourseId(int courseId) { 
    	this.courseId = courseId; 
    	}
    
    public Date getEnrollmentDate() { 
    	return enrollmentDate; 
    	}
    
    public void setEnrollmentDate(Date enrollmentDate) { 
    	this.enrollmentDate = enrollmentDate;
    	}
    
    public String getStudentName() { 
    	return studentName;
    	}
    
    public void setStudentName(String studentName) {
    	this.studentName = studentName;
    	}
    
    public String getCourseName() {
    	return courseName; }
    
    public void setCourseName(String courseName) {
    	this.courseName = courseName; }
}
