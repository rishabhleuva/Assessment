
import com.dao.CourseDao;
import com.pojo.CoursePojo;
import java.util.List;
import java.util.Scanner;

public class CourseApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Course Management MENU ---");
            System.out.println("1. Add a New Course");
            System.out.println("2. List All Courses");
            System.out.println("3. Update Course Information");
            System.out.println("4. Delete a Course");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    CoursePojo courseToAdd = new CoursePojo();
                    System.out.print("Enter Course Name: ");
                    courseToAdd.setName(scanner.nextLine());
                    System.out.print("Enter Course Fee: ");
                    courseToAdd.setFee(scanner.nextInt());
                    scanner.nextLine();
                    System.out.print("Enter Course Duration: ");
                    courseToAdd.setDuration(scanner.nextLine());
                    CourseDao.insert(courseToAdd);
                    break;
                case 2:
                    System.out.println("\n--- List of All Courses ---");
                    List<CoursePojo> courses = CourseDao.fetch();
                    if (courses.isEmpty()) {
                        System.out.println("No courses found.");
                    } else {
                        for (CoursePojo c : courses) {
                            System.out.println("ID: " + c.getId() + ", Name: " + c.getName() + ", Fee: " + c.getFee() + ", Duration: " + c.getDuration());
                        }
                    }
                    break;
                case 3:
                    CoursePojo courseToUpdate = new CoursePojo();
                    System.out.print("Enter the ID of the course to update: ");
                    courseToUpdate.setId(scanner.nextInt());
                    scanner.nextLine();
                    System.out.print("Enter new Fee: ");
                    courseToUpdate.setFee(scanner.nextInt());
                    scanner.nextLine();
                    System.out.print("Enter new Duration: ");
                    courseToUpdate.setDuration(scanner.nextLine());
                    CourseDao.update(courseToUpdate);
                    break;
                case 4:
                    CoursePojo courseToDelete = new CoursePojo();
                    System.out.print("Enter the ID of the course to delete: ");
                    courseToDelete.setId(scanner.nextInt());
                    scanner.nextLine();
                    CourseDao.delete(courseToDelete);
                    break;
                case 5:
                    System.out.println("Exiting Course Management. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
