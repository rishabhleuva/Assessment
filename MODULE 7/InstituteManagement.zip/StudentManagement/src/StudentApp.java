import com.dao.StudentDao;
import com.pojo.StudentPojo;
import java.util.List;
import java.util.Scanner;

public class StudentApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n--- Student Management System MENU ---");
            System.out.println("1. Add a New Student");
            System.out.println("2. View All Students");
            System.out.println("3. Update a Student");
            System.out.println("4. Delete a Student");
            System.out.println("5. Search Student by ID");
            System.out.println("6. Search Student by Name");
            System.out.println("7. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (choice) {
                case 1: 
                    StudentPojo studentToAdd = new StudentPojo();
                    System.out.print("Enter Name: ");
                    studentToAdd.setName(scanner.nextLine());
                    System.out.print("Enter Email: ");
                    studentToAdd.setEmail(scanner.nextLine());
                    System.out.print("Enter Phone: ");
                    studentToAdd.setPhone(scanner.nextLine());
                    System.out.print("Enter Address: ");
                    studentToAdd.setAddress(scanner.nextLine());

                    StudentDao.insert(studentToAdd);
                    break;

                case 2: 
                    System.out.println("\n--- List of All Students ---");
                    
                    List<StudentPojo> students = StudentDao.fetch();
                    if (students.isEmpty()) {
                        System.out.println("No students found.");
                    } else {
                        for (StudentPojo s : students) {
                            System.out.println("ID: " + s.getId() + ", Name: " + s.getName() + ", Email: " + s.getEmail() + ", Address: " + s.getAddress());
                        }
                    }
                    break;

                case 3: 
                    StudentPojo studentToUpdate = new StudentPojo();
                    System.out.print("Enter the ID of the student to update: ");
                    studentToUpdate.setId(scanner.nextInt());
                    scanner.nextLine(); 

                    System.out.print("Enter new Name: ");
                    studentToUpdate.setName(scanner.nextLine());
                    System.out.print("Enter new Email: ");
                    studentToUpdate.setEmail(scanner.nextLine());
                    System.out.print("Enter new Phone: ");
                    studentToUpdate.setPhone(scanner.nextLine());
                    System.out.print("Enter new Address: ");
                    studentToUpdate.setAddress(scanner.nextLine());

                    StudentDao.update(studentToUpdate);
                    break;

                case 4: 
                    StudentPojo studentToDelete = new StudentPojo();
                    System.out.print("Enter the ID of the student to delete: ");
                    studentToDelete.setId(scanner.nextInt());
                    scanner.nextLine(); 

                    StudentDao.delete(studentToDelete);
                    break;
                
                case 5: 
                    System.out.print("Enter student ID to search for: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); 

                    StudentPojo foundStudentById = StudentDao.fetchbyid(id);
                    if(foundStudentById != null) {
                        System.out.println("Student Found -> ID: " + foundStudentById.getId() + ", Name: " + foundStudentById.getName());
                    } else {
                        System.out.println("No student found with ID: " + id);
                    }
                    break;

                case 6: 
                    System.out.print("Enter student name to search for: ");
                    String name = scanner.nextLine();

                    StudentPojo foundStudentByName = StudentDao.fetchbyname(name);
                    if(foundStudentByName != null) {
                        System.out.println("Student Found -> ID: " + foundStudentByName.getId() + ", Name: " + foundStudentByName.getName());
                    } else {
                        System.out.println("No student found with the name: " + name);
                    }
                    break;

                case 7: 
                    System.out.println("Exiting application. Goodbye!");
                    scanner.close();
                    return; 

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
